export default function AddLeftovers() {
  return (
    <div>
      <h1>Add LeftOvers</h1>
    </div>
  );
}

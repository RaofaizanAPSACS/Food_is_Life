export default function UpdateFoodItems() {
  return (
    <div>
      <h1>Update Food Items</h1>
    </div>
  );
}
